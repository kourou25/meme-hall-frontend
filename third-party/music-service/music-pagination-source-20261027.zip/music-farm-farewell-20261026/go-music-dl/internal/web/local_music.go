package web

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"mime"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/dhowden/tag"
	"github.com/gin-gonic/gin"
	"github.com/guohuiyuan/go-music-dl/core"
	"github.com/guohuiyuan/music-lib/model"
	"github.com/guohuiyuan/music-lib/utils"
	"gorm.io/gorm/clause"
)

const (
	localMusicSource         = "local"
	legacyLocalMusicSource   = "local-file"
	localMusicScanCacheTTL   = 10 * time.Second
	autoCacheMaxRequestBytes = 64 << 10
	autoCacheMaxConcurrent   = 2
)

var localMusicDownloadDirProvider = func() string {
	return core.GetWebSettings().DownloadDir
}

var localMusicAudioExts = map[string]struct{}{
	".aac":  {},
	".flac": {},
	".m4a":  {},
	".mp3":  {},
	".ogg":  {},
	".wav":  {},
	".wma":  {},
}

var localMusicCoverExts = []string{".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}
var localMusicLyricExts = []string{".lrc", ".txt", ".lyric"}
var localMusicMetaCacheMu sync.RWMutex
var localMusicMetaCache = make(map[string]*localMusicTrack)
var localMusicMetaCacheRoot string
var localMusicScanCacheMu sync.RWMutex
var localMusicScanCache localMusicScanSnapshot
var localMusicScanRefreshMu sync.Mutex
var localMusicScanRefreshInFlight bool
var autoCacheMu sync.Mutex
var autoCacheInFlight = make(map[string]struct{})
var autoCacheSlots = make(chan struct{}, autoCacheMaxConcurrent)
var autoCacheSaveSong = core.SaveSongToFileWithTemplate
var autoCacheIndexSavedSong = indexSavedLocalMusicFile
var autoCacheSettingsProvider = core.GetWebSettings

type localMusicScanSnapshot struct {
	Dir       string
	Tracks    []*localMusicTrack
	Exists    bool
	Err       error
	ScannedAt time.Time
}

type localMusicTrack struct {
	ID           string            `json:"id"`
	Source       string            `json:"source"`
	Name         string            `json:"name"`
	Artist       string            `json:"artist"`
	Album        string            `json:"album"`
	Cover        string            `json:"cover"`
	Duration     int               `json:"duration"`
	Filename     string            `json:"filename"`
	RelPath      string            `json:"rel_path"`
	Ext          string            `json:"ext"`
	Size         int64             `json:"size"`
	SizeText     string            `json:"size_text"`
	ModifiedAt   time.Time         `json:"modified_at"`
	Missing      []string          `json:"missing"`
	AlreadyAdded bool              `json:"already_added,omitempty"`
	Extra        map[string]string `json:"extra"`

	absPath string
	modTime time.Time
}

type localMusicDupItem struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Artist   string `json:"artist"`
	Size     int64  `json:"size"`
	Duration int    `json:"duration"`
	Ext      string `json:"ext"`
	RelPath  string `json:"rel_path"`
}

type autoCacheRequest struct {
	ID     string          `json:"id"`
	Source string          `json:"source"`
	Name   string          `json:"name"`
	Artist string          `json:"artist"`
	Album  string          `json:"album"`
	Cover  string          `json:"cover"`
	Extra  json.RawMessage `json:"extra"`
}

func decodeAutoCacheRequest(c *gin.Context) (autoCacheRequest, error) {
	c.Request.Body = http.MaxBytesReader(c.Writer, c.Request.Body, autoCacheMaxRequestBytes)
	decoder := json.NewDecoder(c.Request.Body)

	var req autoCacheRequest
	if err := decoder.Decode(&req); err != nil {
		return autoCacheRequest{}, err
	}
	if err := decoder.Decode(&struct{}{}); err != io.EOF {
		return autoCacheRequest{}, errors.New("invalid request")
	}
	return req, nil
}

func parseAutoCacheExtra(raw json.RawMessage) map[string]string {
	extra := make(map[string]string)
	if len(raw) == 0 || string(raw) == "null" {
		return extra
	}

	var encoded string
	if err := json.Unmarshal(raw, &encoded); err == nil {
		_ = json.Unmarshal([]byte(encoded), &extra)
		return extra
	}

	var values map[string]interface{}
	if err := json.Unmarshal(raw, &values); err != nil {
		return extra
	}
	for key, value := range values {
		if text, ok := value.(string); ok {
			extra[key] = text
		}
	}
	return extra
}

func reserveAutoCache(key string) string {
	autoCacheMu.Lock()
	defer autoCacheMu.Unlock()

	if _, exists := autoCacheInFlight[key]; exists {
		return "in_progress"
	}
	select {
	case autoCacheSlots <- struct{}{}:
		autoCacheInFlight[key] = struct{}{}
		return "started"
	default:
		return "busy"
	}
}

func releaseAutoCache(key string) {
	autoCacheMu.Lock()
	delete(autoCacheInFlight, key)
	autoCacheMu.Unlock()
	<-autoCacheSlots
}

// indexSavedLocalMusicFile indexes the file that was just written instead of
// rescanning the entire download directory after every download or cache.
func indexSavedLocalMusicFile(result *core.DownloadedSong, downloadDir string) {
	if result == nil || strings.TrimSpace(result.SavedPath) == "" {
		return
	}

	rootDir := strings.TrimSpace(downloadDir)
	if rootDir == "" {
		rootDir = localMusicDownloadDir()
	}
	rootAbs, err := filepath.Abs(rootDir)
	if err != nil {
		return
	}
	track, err := buildLocalMusicTrackFast(rootAbs, result.SavedPath)
	if err != nil {
		return
	}

	upsertLocalMusicIndexRow(track)
	invalidateLocalMusicScanCache()
}

func extractBitrateFromAudioFile(absPath string) int {
	info, err := os.Stat(absPath)
	if err != nil || info.Size() == 0 {
		return 0
	}
	return 0 // 简单占位，不阻塞匹配流程
}

func RegisterLocalMusicRoutes(api *gin.RouterGroup) {
	api.GET("/local_music_page", func(c *gin.Context) {
		errMsg := ""
		tracks := []*localMusicTrack{}
		if snapshot, ok := cachedLocalMusicScanSnapshot(localMusicDownloadDir(), false); ok {
			tracks = snapshot.Tracks
			if snapshot.Err != nil {
				errMsg = "加载本地音乐失败: " + snapshot.Err.Error()
			} else if !snapshot.Exists {
				errMsg = "本地下载目录不存在，可上传音乐或在设置中调整下载目录"
			}
		}

		renderIndex(c, localMusicTracksToSongs(tracks), nil, "", nil, errMsg, "local_music", "", "", "", false, "", nil)
	})

	api.GET("/local_music", func(c *gin.Context) {
		forceRefresh := c.Query("refresh") == "1" || c.Query("force") == "1"
		offset := parseLocalMusicOffset(c.Query("offset"))
		limit := parseLocalMusicRangeInt(c.Query("limit"), 0)

		// 快速路径：从 SQLite 索引加载（无文件 IO）
		if !forceRefresh && db != nil {
			if tracks, total, ok := loadTracksFromIndex(offset, limit); ok && total > 0 {
				refreshing := refreshLocalMusicScanAsyncIfStale(localMusicDownloadDir())
				c.JSON(http.StatusOK, gin.H{
					"download_dir": filepath.ToSlash(localMusicDownloadDir()),
					"exists":       true,
					"tracks":       tracks,
					"total":        total,
					"offset":       offset,
					"limit":        limit,
					"has_more":     offset+len(tracks) < total,
					"refreshing":   refreshing,
					"scanned_at":   localMusicSnapshotScannedAt(localMusicDownloadDir()),
				})
				return
			}
		}

		// 慢路径：文件系统扫描
		tracks, dir, exists, err, refreshing, scannedAt := scanLocalMusicTracksCached(forceRefresh)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		pageTracks := paginateLocalMusicTracks(tracks, offset, limit)
		markAlreadyAddedLocalTracks(c.Query("collection_id"), pageTracks)

		// 扫描完成后同步到 SQLite 索引（异步），空扫描也要清除旧行。
		if !refreshing {
			go func() { _ = syncTracksToIndex(tracks) }()
		}

		c.JSON(http.StatusOK, gin.H{
			"download_dir": filepath.ToSlash(dir),
			"exists":       exists,
			"tracks":       pageTracks,
			"total":        len(tracks),
			"offset":       offset,
			"limit":        limit,
			"has_more":     offset+len(pageTracks) < len(tracks),
			"refreshing":   refreshing,
			"scanned_at":   scannedAt,
		})
	})

	localMusicCoverHandler := func(c *gin.Context) {
		track, err := localMusicTrackByID(c.Query("id"))
		if err != nil {
			c.Status(http.StatusNotFound)
			return
		}
		saveLocal := wantsSaveLocal(c)
		if saveLocal && !allowSaveLocalRequest(c) {
			return
		}

		data, mimeType, ext, err := readLocalMusicCover(track)
		if err != nil || len(data) == 0 {
			c.Status(http.StatusNotFound)
			return
		}
		if saveLocal {
			saveWebAssetResponse(c, localMusicCoverFilename(track, ext), data)
			return
		}
		if c.Query("download") == "1" {
			setDownloadHeader(c, localMusicCoverFilename(track, ext))
		}
		c.Header("Cache-Control", "public, max-age=21600")
		c.Data(http.StatusOK, mimeType, data)
	}
	api.GET("/local_music/cover", localMusicCoverHandler)
	api.POST("/local_music/cover", localMusicCoverHandler)

	api.POST("/local_music/upload", func(c *gin.Context) {
		file, err := c.FormFile("file")
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "请选择要上传的音乐文件"})
			return
		}

		track, err := saveUploadedLocalMusic(file)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		upsertLocalMusicIndexRow(track)
		if err := core.SaveDownloadDedupEntry(track.Name, track.Artist, track.RelPath); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "音乐文件已保存，但曲库索引写入失败: " + err.Error()})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"status": "ok",
			"track":  track,
		})
	})

	api.DELETE("/local_music", func(c *gin.Context) {
		if err := deleteLocalMusicTrack(c.Query("id")); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	})

	// batchMatchLocalMusic 批量匹配搜索结果的歌曲是否本地已有
	api.POST("/local_music/batch_match", func(c *gin.Context) {
		var req []struct {
			Name   string `json:"name" binding:"required"`
			Artist string `json:"artist"`
		}
		if err := c.ShouldBindJSON(&req); err != nil || len(req) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid request"})
			return
		}

		if db == nil {
			c.JSON(http.StatusOK, gin.H{"matches": []interface{}{}})
			return
		}

		type matchResult struct {
			QueryIndex int    `json:"qi"`
			ID         string `json:"id"`
			Name       string `json:"name"`
			Artist     string `json:"artist"`
			Bitrate    int    `json:"bitrate,omitempty"`
			Size       int64  `json:"size,omitempty"`
			Ext        string `json:"ext,omitempty"`
		}
		matches := make([]matchResult, 0)

		for i, item := range req {
			name := strings.TrimSpace(item.Name)
			artist := strings.TrimSpace(item.Artist)
			if name == "" {
				continue
			}

			row, absPath, err := findLocalMusicMatch(name, artist)
			if err != nil || row == nil {
				continue
			}

			matches = append(matches, matchResult{
				QueryIndex: i,
				ID:         row.ID,
				Name:       row.Name,
				Artist:     row.Artist,
				Bitrate:    extractBitrateFromAudioFile(absPath),
				Size:       row.Size,
				Ext:        row.Ext,
			})
		}

		c.JSON(http.StatusOK, gin.H{"matches": matches})
	})

	// getLocalMusicDuplicates 检测疑似重复的本地歌曲
	api.GET("/local_music/duplicates", func(c *gin.Context) {
		page := parseLocalMusicRangeInt(c.Query("page"), 1)
		pageSize := parseLocalMusicRangeInt(c.Query("page_size"), 10)
		if page < 1 {
			page = 1
		}
		if pageSize < 1 {
			pageSize = 10
		}
		if pageSize > 50 {
			pageSize = 50
		}
		if db == nil {
			c.JSON(http.StatusOK, gin.H{"groups": []interface{}{}, "page": page, "page_size": pageSize, "total": 0, "total_pages": 1})
			return
		}

		type dupGroup struct {
			Name   string              `json:"name"`
			Artist string              `json:"artist"`
			Songs  []localMusicDupItem `json:"songs"`
		}

		type dupRow struct {
			Name     string
			Artist   string
			Count    int
			MaxSize  int64
			MaxBr    int
			AudioCnt int
		}

		duplicateGroups := db.Model(&LocalMusicIndex{}).
			Select("name, artist").
			Group("name, artist").
			Having("COUNT(*) > 1")
		var total int64
		if err := db.Table("(?) AS duplicate_groups", duplicateGroups).Count(&total).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}
		totalPages := 1
		if total > 0 {
			totalPages = int((total + int64(pageSize) - 1) / int64(pageSize))
		}
		if page > totalPages {
			page = totalPages
		}

		var rows []dupRow
		if err := db.Model(&LocalMusicIndex{}).
			Select("name, artist, COUNT(*) as count, MAX(size) as max_size, MAX(CAST(duration AS INTEGER)) as max_br, COUNT(*) as audio_cnt").
			Group("name, artist").
			Having("COUNT(*) > 1").
			Order("count DESC, name ASC, artist ASC").
			Offset((page - 1) * pageSize).
			Limit(pageSize).
			Find(&rows).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		groups := make([]dupGroup, 0, len(rows))
		for _, row := range rows {
			var songs []LocalMusicIndex
			db.Where("name = ? AND artist = ?", row.Name, row.Artist).
				Order("size DESC").
				Find(&songs)

			rootAbs, _ := filepath.Abs(localMusicDownloadDir())
			items := make([]localMusicDupItem, 0, len(songs))
			for _, s := range songs {
				absPath := filepath.Join(rootAbs, filepath.FromSlash(s.RelPath))
				if info, statErr := os.Stat(absPath); statErr != nil || info.IsDir() {
					continue
				}
				items = append(items, localMusicDupItem{
					ID:       s.ID,
					Name:     s.Name,
					Artist:   s.Artist,
					Size:     s.Size,
					Duration: s.Duration,
					Ext:      s.Ext,
					RelPath:  s.RelPath,
				})
			}
			if len(items) >= 2 {
				groups = append(groups, dupGroup{Name: row.Name, Artist: row.Artist, Songs: items})
			}
		}

		c.JSON(http.StatusOK, gin.H{
			"groups":      groups,
			"page":        page,
			"page_size":   pageSize,
			"total":       total,
			"total_pages": totalPages,
		})
	})

	// autoCacheLocalMusic 播放时后台下载缓存
	api.POST("/local_music/auto_cache", func(c *gin.Context) {
		if !allowSameOriginWrite(c) {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "forbidden"})
			return
		}

		req, err := decodeAutoCacheRequest(c)
		if err != nil {
			status := http.StatusBadRequest
			var maxBytesErr *http.MaxBytesError
			if errors.As(err, &maxBytesErr) {
				status = http.StatusRequestEntityTooLarge
			}
			c.JSON(status, gin.H{"error": "invalid request"})
			return
		}

		id := strings.TrimSpace(req.ID)
		source := strings.TrimSpace(req.Source)
		if id == "" || source == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "missing id or source"})
			return
		}
		if isLocalMusicSource(source) {
			c.JSON(http.StatusOK, gin.H{"status": "skipped", "reason": "already local"})
			return
		}

		settings := autoCacheSettingsProvider()
		if !settings.AutoCacheOnPlay {
			c.JSON(http.StatusOK, gin.H{"status": "skipped", "reason": "auto cache disabled"})
			return
		}

		cacheKey := source + ":" + id
		if status := reserveAutoCache(cacheKey); status != "started" {
			c.JSON(http.StatusOK, gin.H{"status": status})
			return
		}

		song := &model.Song{
			ID:     id,
			Source: source,
			Name:   strings.TrimSpace(req.Name),
			Artist: strings.TrimSpace(req.Artist),
			Album:  strings.TrimSpace(req.Album),
			Cover:  strings.TrimSpace(req.Cover),
			Extra:  parseAutoCacheExtra(req.Extra),
		}

		go func() {
			defer releaseAutoCache(cacheKey)
			result, err := autoCacheSaveSong(song, settings.DownloadDir, true, true, settings.DownloadFilenameTemplate)
			if err != nil || result == nil {
				return
			}
			autoCacheIndexSavedSong(result, settings.DownloadDir)
		}()

		c.JSON(http.StatusOK, gin.H{"status": "started"})
	})

	// reindexLocalMusic 手动触发全量重建 SQLite 索引
	api.POST("/local_music/reindex", func(c *gin.Context) {
		syncLocalMusicIndexAsync()
		// 同时清空内存缓存，让下次访问从新索引加载
		localMusicScanCacheMu.Lock()
		localMusicScanCache = localMusicScanSnapshot{}
		localMusicScanCacheMu.Unlock()
		localMusicMetaCacheMu.Lock()
		localMusicMetaCache = make(map[string]*localMusicTrack)
		localMusicMetaCacheRoot = ""
		localMusicMetaCacheMu.Unlock()
		c.JSON(http.StatusOK, gin.H{"status": "started"})
	})

	colAPI := api.Group("/collections")
	colAPI.POST("/:id/local_music", func(c *gin.Context) {
		collection, err := loadCollection(c.Param("id"))
		if err != nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "歌单不存在"})
			return
		}
		if collection.isImported() {
			c.JSON(http.StatusBadRequest, gin.H{"error": "外部导入歌单/专辑不支持直接添加本地音乐"})
			return
		}

		var req struct {
			ID string `json:"id" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "缺少本地音乐 ID"})
			return
		}

		track, err := localMusicTrackByID(req.ID)
		if err != nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "本地音乐不存在或已不在下载目录内"})
			return
		}

		extra, _ := json.Marshal(track.Extra)
		song := SavedSong{
			CollectionID: collection.ID,
			SongID:       track.ID,
			Source:       localMusicSource,
			Extra:        string(extra),
			Name:         track.Name,
			Artist:       track.Artist,
			Cover:        track.Cover,
			Duration:     track.Duration,
			AddedAt:      time.Now(),
		}

		tx := db.Clauses(clause.OnConflict{DoNothing: true}).Create(&song)
		if tx.Error != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "添加失败: " + tx.Error.Error()})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"status":    "ok",
			"duplicate": tx.RowsAffected == 0,
			"song":      song,
		})
	})

	colAPI.POST("/:id/local_music/batch", func(c *gin.Context) {
		collection, err := loadCollection(c.Param("id"))
		if err != nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "歌单不存在"})
			return
		}
		if collection.isImported() {
			c.JSON(http.StatusBadRequest, gin.H{"error": "外部导入歌单/专辑不支持直接添加本地音乐"})
			return
		}

		var req struct {
			IDs []string `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil || len(req.IDs) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"error": "缺少本地音乐 ID 列表"})
			return
		}

		songs := make([]SavedSong, 0, len(req.IDs))
		failed := 0
		for _, id := range req.IDs {
			track, err := localMusicTrackByID(id)
			if err != nil {
				failed++
				continue
			}
			extra, _ := json.Marshal(track.Extra)
			songs = append(songs, SavedSong{
				CollectionID: collection.ID,
				SongID:       track.ID,
				Source:       localMusicSource,
				Extra:        string(extra),
				Name:         track.Name,
				Artist:       track.Artist,
				Cover:        track.Cover,
				Duration:     track.Duration,
				AddedAt:      time.Now(),
			})
		}

		added := 0
		if len(songs) > 0 {
			tx := db.Clauses(clause.OnConflict{DoNothing: true}).Create(&songs)
			if tx.Error != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "批量添加失败: " + tx.Error.Error()})
				return
			}
			added = int(tx.RowsAffected)
		}

		c.JSON(http.StatusOK, gin.H{
			"status":    "ok",
			"requested": len(req.IDs),
			"added":     added,
			"duplicate": len(songs) - added,
			"failed":    failed,
		})
	})
}

func isLocalMusicSource(source string) bool {
	source = strings.TrimSpace(source)
	return source == localMusicSource || source == legacyLocalMusicSource
}

func localMusicTracksToSongs(tracks []*localMusicTrack) []model.Song {
	songs := make([]model.Song, 0, len(tracks))
	for _, track := range tracks {
		if track == nil {
			continue
		}
		songs = append(songs, model.Song{
			ID:       track.ID,
			Source:   localMusicSource,
			Name:     track.Name,
			Artist:   track.Artist,
			Album:    track.Album,
			Cover:    track.Cover,
			Duration: track.Duration,
			Extra:    track.Extra,
		})
	}
	return songs
}

func scanLocalMusicTracks() ([]*localMusicTrack, string, bool, error) {
	dir := localMusicDownloadDir()
	info, err := os.Stat(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return []*localMusicTrack{}, dir, false, nil
		}
		return nil, dir, false, err
	}
	if !info.IsDir() {
		return nil, dir, false, fmt.Errorf("本地下载路径不是目录: %s", dir)
	}

	rootAbs, err := filepath.Abs(dir)
	if err != nil {
		return nil, dir, true, err
	}
	// Persisted index rows are also a metadata cache. Reuse their titles,
	// durations and cover information instead of reading tags and launching
	// ffprobe again for every file after an app restart.
	hydrateLocalMusicMetaCacheFromIndex(rootAbs)

	tracks := make([]*localMusicTrack, 0)
	err = filepath.WalkDir(rootAbs, func(path string, entry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return nil
		}
		if entry.IsDir() {
			if entry.Name() == ".git" || strings.HasPrefix(entry.Name(), ".") {
				if path != rootAbs {
					return filepath.SkipDir
				}
			}
			return nil
		}
		if !isLocalMusicAudioFile(path) {
			return nil
		}

		track, err := buildLocalMusicTrackFast(rootAbs, path)
		if err == nil {
			tracks = append(tracks, track)
		}
		return nil
	})
	if err != nil {
		return nil, dir, true, err
	}

	sort.SliceStable(tracks, func(i, j int) bool {
		if !tracks[i].modTime.Equal(tracks[j].modTime) {
			return tracks[i].modTime.After(tracks[j].modTime)
		}
		return strings.ToLower(tracks[i].RelPath) < strings.ToLower(tracks[j].RelPath)
	})

	return tracks, dir, true, nil
}

func scanLocalMusicTracksCached(force bool) ([]*localMusicTrack, string, bool, error, bool, time.Time) {
	dir := localMusicDownloadDir()
	if !force {
		if snapshot, ok := cachedLocalMusicScanSnapshot(dir, false); ok {
			if time.Since(snapshot.ScannedAt) < localMusicScanCacheTTL {
				return snapshot.Tracks, snapshot.Dir, snapshot.Exists, snapshot.Err, false, snapshot.ScannedAt
			}
			if snapshot.Err == nil {
				refreshLocalMusicScanAsyncIfStale(dir)
				return snapshot.Tracks, snapshot.Dir, snapshot.Exists, snapshot.Err, true, snapshot.ScannedAt
			}
		}
	}

	tracks, scanDir, exists, err := scanLocalMusicTracks()
	snapshot := localMusicScanSnapshot{
		Dir:       scanDir,
		Tracks:    cloneLocalMusicTrackSlice(tracks),
		Exists:    exists,
		Err:       err,
		ScannedAt: time.Now(),
	}
	storeLocalMusicScanSnapshot(snapshot)
	return cloneLocalMusicTrackSlice(tracks), scanDir, exists, err, false, snapshot.ScannedAt
}

func localMusicSnapshotScannedAt(dir string) time.Time {
	snapshot, ok := cachedLocalMusicScanSnapshot(dir, false)
	if !ok {
		return time.Time{}
	}
	return snapshot.ScannedAt
}

func refreshLocalMusicScanAsyncIfStale(dir string) bool {
	if snapshot, ok := cachedLocalMusicScanSnapshot(dir, false); ok &&
		snapshot.Err == nil &&
		time.Since(snapshot.ScannedAt) < localMusicScanCacheTTL {
		return false
	}
	return refreshLocalMusicScanAsync(dir)
}

func refreshLocalMusicScanAsync(dir string) bool {
	localMusicScanRefreshMu.Lock()
	if localMusicScanRefreshInFlight {
		localMusicScanRefreshMu.Unlock()
		return false
	}
	localMusicScanRefreshInFlight = true
	localMusicScanRefreshMu.Unlock()

	go func() {
		defer func() {
			localMusicScanRefreshMu.Lock()
			localMusicScanRefreshInFlight = false
			localMusicScanRefreshMu.Unlock()
		}()

		tracks, scanDir, exists, err := scanLocalMusicTracks()
		if filepath.Clean(scanDir) != filepath.Clean(dir) {
			return
		}
		nextSnapshot := localMusicScanSnapshot{
			Dir:       scanDir,
			Tracks:    cloneLocalMusicTrackSlice(tracks),
			Exists:    exists,
			Err:       err,
			ScannedAt: time.Now(),
		}
		previousSnapshot, hasPreviousSnapshot := cachedLocalMusicScanSnapshot(scanDir, false)
		if err == nil && (!hasPreviousSnapshot || !sameLocalMusicScanContents(previousSnapshot, nextSnapshot)) {
			if syncErr := syncTracksToIndex(tracks); syncErr != nil {
				return
			}
		}
		storeLocalMusicScanSnapshot(nextSnapshot)
	}()
	return true
}

func sameLocalMusicScanContents(previous localMusicScanSnapshot, next localMusicScanSnapshot) bool {
	if previous.Exists != next.Exists || (previous.Err == nil) != (next.Err == nil) {
		return false
	}
	if previous.Err != nil && next.Err != nil && previous.Err.Error() != next.Err.Error() {
		return false
	}
	if len(previous.Tracks) != len(next.Tracks) {
		return false
	}
	for i := range previous.Tracks {
		before, after := previous.Tracks[i], next.Tracks[i]
		if before == nil || after == nil {
			if before != after {
				return false
			}
			continue
		}
		if before.ID != after.ID || before.RelPath != after.RelPath || before.Size != after.Size || !before.ModifiedAt.Equal(after.ModifiedAt) {
			return false
		}
	}
	return true
}

func cachedLocalMusicScanSnapshot(dir string, freshOnly bool) (localMusicScanSnapshot, bool) {
	localMusicScanCacheMu.RLock()
	snapshot := localMusicScanCache
	localMusicScanCacheMu.RUnlock()

	if strings.TrimSpace(snapshot.Dir) == "" || filepath.Clean(snapshot.Dir) != filepath.Clean(dir) {
		return localMusicScanSnapshot{}, false
	}
	if freshOnly && time.Since(snapshot.ScannedAt) >= localMusicScanCacheTTL {
		return localMusicScanSnapshot{}, false
	}
	snapshot.Tracks = cloneLocalMusicTrackSlice(snapshot.Tracks)
	return snapshot, true
}

func storeLocalMusicScanSnapshot(snapshot localMusicScanSnapshot) {
	snapshot.Tracks = cloneLocalMusicTrackSlice(snapshot.Tracks)
	localMusicScanCacheMu.Lock()
	localMusicScanCache = snapshot
	localMusicScanCacheMu.Unlock()
}

func invalidateLocalMusicScanCache() {
	localMusicScanCacheMu.Lock()
	localMusicScanCache = localMusicScanSnapshot{}
	localMusicScanCacheMu.Unlock()
}

// Offset is a position in the complete library, not a page-size limit.
func parseLocalMusicOffset(raw string) int {
	value, err := strconv.Atoi(strings.TrimSpace(raw))
	if err != nil || value < 0 {
		return 0
	}
	return value
}

func parseLocalMusicRangeInt(raw string, fallback int) int {
	value, err := strconv.Atoi(strings.TrimSpace(raw))
	if err != nil || value < 0 {
		return fallback
	}
	if value > 1000 {
		return 1000
	}
	return value
}

func paginateLocalMusicTracks(tracks []*localMusicTrack, offset int, limit int) []*localMusicTrack {
	if offset < 0 {
		offset = 0
	}
	if offset >= len(tracks) {
		return []*localMusicTrack{}
	}
	if limit <= 0 || offset+limit > len(tracks) {
		limit = len(tracks) - offset
	}
	return tracks[offset : offset+limit]
}

func markAlreadyAddedLocalTracks(collectionID string, tracks []*localMusicTrack) {
	if strings.TrimSpace(collectionID) == "" || len(tracks) == 0 || db == nil {
		return
	}

	collection, err := loadCollection(collectionID)
	if err != nil || collection.isImported() {
		return
	}

	ids := make([]string, 0, len(tracks))
	for _, track := range tracks {
		ids = append(ids, track.ID)
	}

	var saved []SavedSong
	if err := db.Where(
		"collection_id = ? AND source IN ? AND song_id IN ?",
		collection.ID,
		[]string{localMusicSource, legacyLocalMusicSource},
		ids,
	).Find(&saved).Error; err != nil {
		return
	}

	added := make(map[string]struct{}, len(saved))
	for _, song := range saved {
		added[song.SongID] = struct{}{}
	}
	for _, track := range tracks {
		_, track.AlreadyAdded = added[track.ID]
	}
}

func localMusicDownloadDir() string {
	dir := strings.TrimSpace(localMusicDownloadDirProvider())
	if dir == "" {
		dir = core.DefaultWebDownloadDir
	}
	return filepath.Clean(dir)
}

func isLocalMusicAudioFile(path string) bool {
	_, ok := localMusicAudioExts[strings.ToLower(filepath.Ext(path))]
	return ok
}

func buildLocalMusicTrackFast(rootAbs string, audioPath string) (*localMusicTrack, error) {
	track, err := buildLocalMusicTrackFallback(rootAbs, audioPath)
	if err != nil {
		return nil, err
	}
	if cached := getCachedLocalMusicTrack(rootAbs, track.RelPath, track.Size, track.modTime); cached != nil {
		cached.absPath = track.absPath
		cached.modTime = track.modTime
		return cached, nil
	}
	return buildLocalMusicTrack(rootAbs, audioPath)
}

func buildLocalMusicTrackFallback(rootAbs string, audioPath string) (*localMusicTrack, error) {
	absPath, err := filepath.Abs(audioPath)
	if err != nil {
		return nil, err
	}
	if !isPathInside(rootAbs, absPath) {
		return nil, errors.New("path is outside local music dir")
	}

	info, err := os.Stat(absPath)
	if err != nil {
		return nil, err
	}
	if info.IsDir() || !isLocalMusicAudioFile(absPath) {
		return nil, errors.New("not a supported audio file")
	}

	rel, err := filepath.Rel(rootAbs, absPath)
	if err != nil {
		return nil, err
	}
	rel = filepath.ToSlash(rel)

	filename := info.Name()
	ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(filename)), ".")
	fallbackName := strings.TrimSuffix(filename, filepath.Ext(filename))
	id := encodeLocalMusicID(rel)
	extra := map[string]string{
		"local_music": "true",
		"file_id":     id,
		"filename":    filename,
		"rel_path":    rel,
		"ext":         ext,
		"size":        strconv.FormatInt(info.Size(), 10),
	}
	cover := ""
	if _, _, ok := localMusicExactSidecarFile(absPath, localMusicCoverExts); ok {
		cover = RoutePrefix + "/local_music/cover?id=" + url.QueryEscape(id)
		extra["cover"] = "true"
		extra["cover_source"] = "sidecar"
	}
	if _, _, ok := localMusicExactSidecarFile(absPath, localMusicLyricExts); ok {
		extra["lyric"] = "true"
		extra["lyric_source"] = "sidecar"
	}

	return &localMusicTrack{
		ID:         id,
		Source:     localMusicSource,
		Name:       strings.TrimSpace(fallbackName),
		Artist:     "未知歌手",
		Album:      "",
		Cover:      cover,
		Duration:   0,
		Filename:   filename,
		RelPath:    rel,
		Ext:        ext,
		Size:       info.Size(),
		SizeText:   core.FormatSize(info.Size()),
		ModifiedAt: info.ModTime(),
		Missing:    []string{"title", "artist", "album"},
		Extra:      extra,
		absPath:    absPath,
		modTime:    info.ModTime(),
	}, nil
}

func buildLocalMusicTrack(rootAbs string, audioPath string) (*localMusicTrack, error) {
	absPath, err := filepath.Abs(audioPath)
	if err != nil {
		return nil, err
	}
	if !isPathInside(rootAbs, absPath) {
		return nil, errors.New("path is outside local music dir")
	}

	info, err := os.Stat(absPath)
	if err != nil {
		return nil, err
	}
	if info.IsDir() || !isLocalMusicAudioFile(absPath) {
		return nil, errors.New("not a supported audio file")
	}

	rel, err := filepath.Rel(rootAbs, absPath)
	if err != nil {
		return nil, err
	}
	rel = filepath.ToSlash(rel)

	filename := info.Name()
	ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(filename)), ".")
	if cached := getCachedLocalMusicTrack(rootAbs, rel, info.Size(), info.ModTime()); cached != nil {
		cached.absPath = absPath
		cached.modTime = info.ModTime()
		return cached, nil
	}
	fallbackName := strings.TrimSuffix(filename, filepath.Ext(filename))
	name := ""
	artist := ""
	album := ""
	hasEmbeddedCover := false
	hasEmbeddedLyric := false

	if file, err := os.Open(absPath); err == nil {
		if metadata, readErr := tag.ReadFrom(file); readErr == nil {
			name = strings.TrimSpace(metadata.Title())
			artist = strings.TrimSpace(metadata.Artist())
			album = strings.TrimSpace(metadata.Album())
			if picture := metadata.Picture(); picture != nil && len(picture.Data) > 0 {
				hasEmbeddedCover = true
			}
			hasEmbeddedLyric = strings.TrimSpace(metadata.Lyrics()) != ""
		}
		_ = file.Close()
	}

	missing := make([]string, 0, 3)
	if strings.TrimSpace(name) == "" {
		name = fallbackName
		missing = append(missing, "title")
	}
	if strings.TrimSpace(artist) == "" {
		artist = "未知歌手"
		missing = append(missing, "artist")
	}
	if strings.TrimSpace(album) == "" {
		missing = append(missing, "album")
	}

	id := encodeLocalMusicID(rel)
	extra := map[string]string{
		"local_music": "true",
		"file_id":     id,
		"filename":    filename,
		"rel_path":    rel,
		"ext":         ext,
		"size":        strconv.FormatInt(info.Size(), 10),
	}
	if album != "" {
		extra["album"] = album
	}

	cover := ""
	if hasEmbeddedCover {
		cover = RoutePrefix + "/local_music/cover?id=" + url.QueryEscape(id)
		extra["cover"] = "true"
		extra["cover_source"] = "embedded"
	} else if _, _, ok := localMusicSidecarFile(absPath, localMusicCoverExts); ok {
		cover = RoutePrefix + "/local_music/cover?id=" + url.QueryEscape(id)
		extra["cover"] = "true"
		extra["cover_source"] = "sidecar"
	}

	if hasEmbeddedLyric {
		extra["lyric"] = "true"
		extra["lyric_source"] = "embedded"
	} else if _, _, ok := localMusicSidecarFile(absPath, localMusicLyricExts); ok {
		extra["lyric"] = "true"
		extra["lyric_source"] = "sidecar"
	}

	track := &localMusicTrack{
		ID:         id,
		Source:     localMusicSource,
		Name:       strings.TrimSpace(name),
		Artist:     strings.TrimSpace(artist),
		Album:      strings.TrimSpace(album),
		Cover:      cover,
		Duration:   0,
		Filename:   filename,
		RelPath:    rel,
		Ext:        ext,
		Size:       info.Size(),
		SizeText:   core.FormatSize(info.Size()),
		ModifiedAt: info.ModTime(),
		Missing:    missing,
		Extra:      extra,
		absPath:    absPath,
		modTime:    info.ModTime(),
	}
	if probe, err := probeLocalMusicTrack(track); err == nil && probe != nil {
		applyLocalProbeResult(track, probe)
	}
	cacheLocalMusicTrack(rootAbs, track)
	return track, nil
}

func getCachedLocalMusicTrack(rootAbs string, relPath string, size int64, modTime time.Time) *localMusicTrack {
	localMusicMetaCacheMu.RLock()
	defer localMusicMetaCacheMu.RUnlock()
	track := localMusicMetaCache[localMusicMetaCacheKey(rootAbs, relPath)]
	if track == nil || track.Size != size || !track.modTime.Equal(modTime) {
		return nil
	}
	return cloneLocalMusicTrack(track)
}

func cacheLocalMusicTrack(rootAbs string, track *localMusicTrack) {
	if track == nil || strings.TrimSpace(track.RelPath) == "" {
		return
	}
	localMusicMetaCacheMu.Lock()
	localMusicMetaCache[localMusicMetaCacheKey(rootAbs, track.RelPath)] = cloneLocalMusicTrack(track)
	localMusicMetaCacheMu.Unlock()
}

func localMusicMetaCacheKey(rootAbs string, relPath string) string {
	root, err := filepath.Abs(rootAbs)
	if err != nil {
		root = rootAbs
	}
	return filepath.Clean(root) + "|" + filepath.ToSlash(relPath)
}

func cloneLocalMusicTrack(track *localMusicTrack) *localMusicTrack {
	if track == nil {
		return nil
	}
	next := *track
	if track.Missing != nil {
		next.Missing = append([]string(nil), track.Missing...)
	}
	if track.Extra != nil {
		next.Extra = make(map[string]string, len(track.Extra))
		for key, value := range track.Extra {
			next.Extra[key] = value
		}
	}
	return &next
}

func cloneLocalMusicTrackSlice(tracks []*localMusicTrack) []*localMusicTrack {
	if len(tracks) == 0 {
		return []*localMusicTrack{}
	}
	cloned := make([]*localMusicTrack, 0, len(tracks))
	for _, track := range tracks {
		if track == nil {
			continue
		}
		cloned = append(cloned, cloneLocalMusicTrack(track))
	}
	return cloned
}

func localMusicTrackByID(id string) (*localMusicTrack, error) {
	rel, err := decodeLocalMusicID(id)
	if err != nil {
		return nil, err
	}
	rel = strings.TrimSpace(rel)
	if rel == "" {
		return nil, errors.New("empty local music id")
	}

	cleanRel := filepath.Clean(filepath.FromSlash(rel))
	if filepath.IsAbs(cleanRel) || cleanRel == "." || cleanRel == ".." || strings.HasPrefix(cleanRel, ".."+string(filepath.Separator)) {
		return nil, errors.New("invalid local music path")
	}

	rootAbs, err := filepath.Abs(localMusicDownloadDir())
	if err != nil {
		return nil, err
	}
	audioPath := filepath.Join(rootAbs, cleanRel)
	absPath, err := filepath.Abs(audioPath)
	if err != nil {
		return nil, err
	}
	if !isPathInside(rootAbs, absPath) {
		return nil, errors.New("local music path escaped root")
	}

	return buildLocalMusicTrack(rootAbs, absPath)
}

func encodeLocalMusicID(relPath string) string {
	return base64.RawURLEncoding.EncodeToString([]byte(filepath.ToSlash(relPath)))
}

func decodeLocalMusicID(id string) (string, error) {
	raw, err := base64.RawURLEncoding.DecodeString(strings.TrimSpace(id))
	if err != nil {
		return "", err
	}
	return string(raw), nil
}

func isPathInside(rootAbs string, targetAbs string) bool {
	rel, err := filepath.Rel(rootAbs, targetAbs)
	if err != nil {
		return false
	}
	return rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)) && !filepath.IsAbs(rel)
}

func saveUploadedLocalMusic(file *multipart.FileHeader) (*localMusicTrack, error) {
	filename, err := sanitizeLocalMusicUploadName(file.Filename)
	if err != nil {
		return nil, err
	}

	dir := localMusicDownloadDir()
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, err
	}
	rootAbs, err := filepath.Abs(dir)
	if err != nil {
		return nil, err
	}
	dstPath := uniqueLocalMusicPath(rootAbs, filename)

	src, err := file.Open()
	if err != nil {
		return nil, err
	}
	defer src.Close()

	dst, err := os.OpenFile(dstPath, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if err != nil {
		return nil, err
	}
	_, copyErr := io.Copy(dst, src)
	closeErr := dst.Close()
	if copyErr != nil {
		_ = os.Remove(dstPath)
		return nil, copyErr
	}
	if closeErr != nil {
		_ = os.Remove(dstPath)
		return nil, closeErr
	}

	track, err := buildLocalMusicTrack(rootAbs, dstPath)
	if err == nil {
		invalidateLocalMusicScanCache()
	}
	return track, err
}

func sanitizeLocalMusicUploadName(name string) (string, error) {
	name = strings.TrimSpace(name)
	name = strings.ReplaceAll(name, "\\", "/")
	name = filepath.Base(name)
	ext := strings.ToLower(filepath.Ext(name))
	if _, ok := localMusicAudioExts[ext]; !ok {
		return "", fmt.Errorf("仅支持 mp3、flac、m4a、ogg、wav、wma、aac 音频文件")
	}

	base := strings.TrimSuffix(name, filepath.Ext(name))
	base = strings.TrimSpace(utils.SanitizeFilename(base))
	if base == "" {
		base = "local-music"
	}
	return base + ext, nil
}

func uniqueLocalMusicPath(dir string, filename string) string {
	ext := filepath.Ext(filename)
	base := strings.TrimSuffix(filename, ext)
	candidate := filepath.Join(dir, filename)
	if _, err := os.Stat(candidate); os.IsNotExist(err) {
		return candidate
	}
	for i := 1; ; i++ {
		candidate = filepath.Join(dir, fmt.Sprintf("%s (%d)%s", base, i, ext))
		if _, err := os.Stat(candidate); os.IsNotExist(err) {
			return candidate
		}
	}
}

type localProbeResult struct {
	Duration int
	Bitrate  int
	Title    string
	Artist   string
	Album    string
}

func probeLocalMusicTrack(track *localMusicTrack) (*localProbeResult, error) {
	if track == nil || strings.TrimSpace(track.absPath) == "" {
		return nil, errors.New("empty local music track")
	}
	ffprobePath, err := core.ResolveFFprobePath()
	if err != nil {
		return nil, err
	}

	cmd := exec.Command(ffprobePath, "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", track.absPath)
	core.HideCommandWindow(cmd)
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}

	var payload struct {
		Format struct {
			Duration string            `json:"duration"`
			BitRate  string            `json:"bit_rate"`
			Tags     map[string]string `json:"tags"`
		} `json:"format"`
		Streams []struct {
			CodecType string            `json:"codec_type"`
			Duration  string            `json:"duration"`
			BitRate   string            `json:"bit_rate"`
			Tags      map[string]string `json:"tags"`
		} `json:"streams"`
	}
	if err := json.Unmarshal(out, &payload); err != nil {
		return nil, err
	}

	result := &localProbeResult{
		Duration: secondsFromProbe(payload.Format.Duration),
		Bitrate:  kbpsFromProbe(payload.Format.BitRate),
		Title:    probeTag(payload.Format.Tags, "title"),
		Artist:   probeTag(payload.Format.Tags, "artist"),
		Album:    probeTag(payload.Format.Tags, "album"),
	}

	for _, stream := range payload.Streams {
		if stream.CodecType != "audio" {
			continue
		}
		if result.Duration <= 0 {
			result.Duration = secondsFromProbe(stream.Duration)
		}
		if result.Bitrate <= 0 {
			result.Bitrate = kbpsFromProbe(stream.BitRate)
		}
		if result.Title == "" {
			result.Title = probeTag(stream.Tags, "title")
		}
		if result.Artist == "" {
			result.Artist = probeTag(stream.Tags, "artist")
		}
		if result.Album == "" {
			result.Album = probeTag(stream.Tags, "album")
		}
		break
	}

	return result, nil
}

func applyLocalProbeResult(track *localMusicTrack, probe *localProbeResult) {
	if track == nil || probe == nil {
		return
	}
	if track.Extra == nil {
		track.Extra = make(map[string]string)
	}
	if probe.Duration > 0 {
		track.Duration = probe.Duration
		track.Extra["duration"] = strconv.Itoa(probe.Duration)
	}
	if probe.Title != "" && containsString(track.Missing, "title") {
		track.Name = probe.Title
		track.Extra["title"] = probe.Title
		track.Missing = removeString(track.Missing, "title")
	}
	if probe.Artist != "" && containsString(track.Missing, "artist") {
		track.Artist = probe.Artist
		track.Extra["artist"] = probe.Artist
		track.Missing = removeString(track.Missing, "artist")
	}
	if probe.Album != "" && containsString(track.Missing, "album") {
		track.Album = probe.Album
		track.Extra["album"] = probe.Album
		track.Missing = removeString(track.Missing, "album")
	}
	if probe.Bitrate > 0 {
		track.Extra["bitrate"] = strconv.Itoa(probe.Bitrate)
	}
}

func secondsFromProbe(raw string) int {
	value, err := strconv.ParseFloat(strings.TrimSpace(raw), 64)
	if err != nil || value <= 0 {
		return 0
	}
	return int(value + 0.5)
}

func kbpsFromProbe(raw string) int {
	value, err := strconv.ParseInt(strings.TrimSpace(raw), 10, 64)
	if err != nil || value <= 0 {
		return 0
	}
	return int(value / 1000)
}

func probeTag(tags map[string]string, key string) string {
	if len(tags) == 0 {
		return ""
	}
	for k, v := range tags {
		if strings.EqualFold(strings.TrimSpace(k), key) {
			return strings.TrimSpace(v)
		}
	}
	return ""
}

func localMusicSidecarFile(audioPath string, exts []string) (string, string, bool) {
	basePath := strings.TrimSuffix(audioPath, filepath.Ext(audioPath))
	for _, ext := range exts {
		candidate := basePath + ext
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate, ext, true
		}
	}

	dir := filepath.Dir(audioPath)
	baseName := filepath.Base(basePath)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return "", "", false
	}
	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		entryExt := strings.ToLower(filepath.Ext(entry.Name()))
		if !containsString(exts, entryExt) {
			continue
		}
		entryBase := strings.TrimSuffix(entry.Name(), filepath.Ext(entry.Name()))
		if strings.EqualFold(entryBase, baseName) {
			return filepath.Join(dir, entry.Name()), entryExt, true
		}
	}
	return "", "", false
}

func localMusicExactSidecarFile(audioPath string, exts []string) (string, string, bool) {
	basePath := strings.TrimSuffix(audioPath, filepath.Ext(audioPath))
	for _, ext := range exts {
		candidate := basePath + ext
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate, ext, true
		}
	}
	return "", "", false
}

func readLocalMusicPicture(audioPath string) (*tag.Picture, error) {
	file, err := os.Open(audioPath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	metadata, err := tag.ReadFrom(file)
	if err != nil {
		return nil, err
	}
	return metadata.Picture(), nil
}

func readLocalMusicLyrics(audioPath string) (string, error) {
	file, err := os.Open(audioPath)
	if err == nil {
		metadata, readErr := tag.ReadFrom(file)
		_ = file.Close()
		if readErr == nil {
			if lyrics := strings.TrimSpace(metadata.Lyrics()); lyrics != "" {
				return lyrics, nil
			}
		}
	} else {
		return "", err
	}

	sidecarPath, _, ok := localMusicSidecarFile(audioPath, localMusicLyricExts)
	if !ok {
		return "", errors.New("local lyric not found")
	}
	data, err := os.ReadFile(sidecarPath)
	if err != nil {
		return "", err
	}
	lyrics := strings.TrimSpace(string(data))
	if lyrics == "" {
		return "", errors.New("local lyric is empty")
	}
	return lyrics, nil
}

func readLocalMusicCover(track *localMusicTrack) ([]byte, string, string, error) {
	if track == nil {
		return nil, "", "", errors.New("empty local music track")
	}

	picture, err := readLocalMusicPicture(track.absPath)
	if err == nil && picture != nil && len(picture.Data) > 0 {
		mimeType := strings.TrimSpace(picture.MIMEType)
		if mimeType == "" {
			mimeType = "image/jpeg"
		}
		return picture.Data, mimeType, imageExtByMime(mimeType), nil
	}

	sidecarPath, ext, ok := localMusicSidecarFile(track.absPath, localMusicCoverExts)
	if !ok {
		return nil, "", "", errors.New("local cover not found")
	}
	data, err := os.ReadFile(sidecarPath)
	if err != nil {
		return nil, "", "", err
	}
	mimeType := localImageMimeByExt(ext)
	return data, mimeType, ext, nil
}

func localImageMimeByExt(ext string) string {
	ext = strings.ToLower(ext)
	switch ext {
	case ".jpg", ".jpeg":
		return "image/jpeg"
	case ".png":
		return "image/png"
	case ".webp":
		return "image/webp"
	case ".bmp":
		return "image/bmp"
	case ".gif":
		return "image/gif"
	default:
		if mimeType := mime.TypeByExtension(ext); strings.HasPrefix(mimeType, "image/") {
			return mimeType
		}
		return "image/jpeg"
	}
}

func imageExtByMime(mimeType string) string {
	switch strings.ToLower(strings.TrimSpace(mimeType)) {
	case "image/png":
		return ".png"
	case "image/webp":
		return ".webp"
	case "image/bmp", "image/x-ms-bmp":
		return ".bmp"
	case "image/gif":
		return ".gif"
	default:
		return ".jpg"
	}
}

func localMusicCoverFilename(track *localMusicTrack, ext string) string {
	if strings.TrimSpace(ext) == "" {
		ext = ".jpg"
	}
	name := strings.TrimSpace(track.Name)
	if name == "" {
		name = strings.TrimSuffix(track.Filename, filepath.Ext(track.Filename))
	}
	artist := strings.TrimSpace(track.Artist)
	if artist == "" {
		artist = "Unknown"
	}
	return utils.SanitizeFilename(fmt.Sprintf("%s - %s%s", name, artist, ext))
}

func localMusicLyricFilename(track *localMusicTrack) string {
	name := strings.TrimSpace(track.Name)
	if name == "" {
		name = strings.TrimSuffix(track.Filename, filepath.Ext(track.Filename))
	}
	artist := strings.TrimSpace(track.Artist)
	if artist == "" {
		artist = "Unknown"
	}
	return utils.SanitizeFilename(fmt.Sprintf("%s - %s.lrc", name, artist))
}

func serveLocalMusicLyric(c *gin.Context, song *model.Song, download bool, saveLocal ...bool) {
	if song == nil {
		c.String(http.StatusNotFound, "Lyric not found")
		return
	}
	track, err := localMusicTrackByID(song.ID)
	if err != nil {
		if download {
			c.String(http.StatusNotFound, "Lyric not found")
		} else {
			c.String(http.StatusOK, "[00:00.00] 纯音乐 / 无歌词")
		}
		return
	}

	lyrics, err := readLocalMusicLyrics(track.absPath)
	if err != nil || strings.TrimSpace(lyrics) == "" {
		if download {
			c.String(http.StatusNotFound, "Lyric not found")
		} else {
			c.String(http.StatusOK, "[00:00.00] 纯音乐 / 无歌词")
		}
		return
	}

	lyrics = formatLyricForMode(lyrics, c.DefaultQuery("format", "auto"))
	c.Header("X-Lyric-Format", classifyLyricFormat(lyrics))
	if download {
		if len(saveLocal) > 0 && saveLocal[0] {
			saveWebAssetResponse(c, localMusicLyricFilename(track), []byte(lyrics))
			return
		}
		setDownloadHeader(c, localMusicLyricFilename(track))
	}
	c.String(http.StatusOK, lyrics)
}

func inspectLocalMusicFile(id string, duration string) (gin.H, error) {
	track, err := localMusicTrackByID(id)
	if err != nil {
		return gin.H{"valid": false}, err
	}

	if probe, err := probeLocalMusicTrack(track); err == nil && probe != nil {
		applyLocalProbeResult(track, probe)
	}
	if rootAbs, err := filepath.Abs(localMusicDownloadDir()); err == nil {
		cacheLocalMusicTrack(rootAbs, track)
	}

	bitrate := "-"
	if kbps, _ := strconv.Atoi(track.Extra["bitrate"]); kbps > 0 {
		bitrate = fmt.Sprintf("%d kbps", kbps)
	} else if seconds := track.Duration; seconds > 0 && track.Size > 0 {
		bitrate = fmt.Sprintf("%d kbps", int((track.Size*8)/int64(seconds)/1000))
	} else if seconds, _ := strconv.Atoi(strings.TrimSpace(duration)); seconds > 0 && track.Size > 0 {
		bitrate = fmt.Sprintf("%d kbps", int((track.Size*8)/int64(seconds)/1000))
	}

	return gin.H{
		"valid":    true,
		"url":      "",
		"size":     track.SizeText,
		"bitrate":  bitrate,
		"duration": track.Duration,
		"song": gin.H{
			"id":       track.ID,
			"source":   track.Source,
			"name":     track.Name,
			"artist":   track.Artist,
			"album":    track.Album,
			"cover":    track.Cover,
			"duration": track.Duration,
			"extra":    track.Extra,
		},
	}, nil
}

func containsString(values []string, target string) bool {
	for _, value := range values {
		if value == target {
			return true
		}
	}
	return false
}

func removeString(values []string, target string) []string {
	filtered := values[:0]
	for _, value := range values {
		if value != target {
			filtered = append(filtered, value)
		}
	}
	return filtered
}

func deleteLocalMusicTrack(id string) error {
	track, err := localMusicTrackByID(id)
	if err != nil {
		return errors.New("本地音乐不存在或已不在下载目录内")
	}
	// 硬删除：删磁盘文件 + 删索引行。收藏歌单里的引用条目保留，
	// 之后在歌单详情页会显示为失效，可换源到在线源。
	if err := os.Remove(track.absPath); err != nil {
		return err
	}
	deleteLocalMusicIndexRow(track.ID)
	// 同步清掉去重记录，否则这首歌再下载时会因为记录残留被判成「已下载」而跳过。
	_ = core.ForgetDownloadedSong(track.Name, track.Artist, track.RelPath)
	invalidateLocalMusicScanCache()
	return nil
}

func serveLocalMusicDownload(c *gin.Context, id string, saveLocal bool) {
	track, err := localMusicTrackByID(id)
	if err != nil {
		c.String(http.StatusNotFound, "Local music not found")
		return
	}

	if saveLocal {
		c.JSON(http.StatusOK, gin.H{
			"status":   "ok",
			"saved":    true,
			"path":     track.absPath,
			"filename": track.Filename,
		})
		return
	}

	file, err := os.Open(track.absPath)
	if err != nil {
		c.String(http.StatusNotFound, "Local music not found")
		return
	}
	defer file.Close()

	c.Header("Content-Type", localAudioMimeByExt(track.Ext))
	setDownloadHeader(c, track.Filename)
	http.ServeContent(c.Writer, c.Request, track.Filename, track.modTime, file)
}

func localAudioMimeByExt(ext string) string {
	switch strings.ToLower(strings.TrimPrefix(ext, ".")) {
	case "aac":
		return "audio/aac"
	case "wav":
		return "audio/wav"
	default:
		return core.AudioMimeByExt(ext)
	}
}
